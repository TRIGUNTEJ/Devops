package com.klu;

import java.lang.ProcessBuilder.Redirect;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import jakarta.security.auth.message.callback.PrivateKeyCallback.Request;
import jakarta.ws.rs.POST;

@Controller
public class SpringController {
  
  @Autowired
  private Repository repo;
  
  @GetMapping("/")
  public String fun1() {
    
    return "home.html";
  }
  
  @GetMapping("/signup")
  public String fun2() {
    
    return "signup.html";
  }
  
  
  
  @PostMapping("/signup")
  public String fun4(@RequestParam String username, @RequestParam String fullname, @RequestParam String email, @RequestParam String password, Model model)
  {
    User user = new User();
      user.setUsername(username);
      user.setFullname(fullname);
      user.setEmail(email);
      user.setPassword(password);
      
      repo.save(user);
      
      return "redirect:/signin";

  }
  
  @GetMapping("/signin")
  public String fun3() {
    
    return "signin.html";
  }
  
  
    @PostMapping("/signin")
    public String signin(@RequestParam String username, @RequestParam String password, Model model) {
        // Validate the user's credentials
        User user = repo.findByUsername(username);
        if (user != null && user.getPassword().equals(password)) {
            // Successful sign-in, redirect to the home page
            return "redirect:/Success.html";
        } else {
            // Invalid credentials, add an error message and return to the sign-in page
            model.addAttribute("error", "Invalid username or password");
            return "hello.jsp";
        }
    }
  
  

}